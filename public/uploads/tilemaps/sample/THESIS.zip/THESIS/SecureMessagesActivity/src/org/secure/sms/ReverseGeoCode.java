package org.secure.sms;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import android.app.Activity;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.telephony.SmsManager;

public class ReverseGeoCode extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		Intent myIntent = getIntent();
		String pAddress = myIntent.getStringExtra("addr");
		Double latitude = myIntent.getDoubleExtra("lat", 0.0);
		Double longitude = myIntent.getDoubleExtra("long", 0.0);
		String provider = myIntent.getStringExtra("prov");
		String holdAddr =  revGeoLocation(latitude,longitude);
		String text = "Lat: "+latitude+" Long:"+longitude+" ";
		SmsManager smsManager = SmsManager.getDefault();
		smsManager.sendTextMessage(pAddress, null, text+" "+provider+" "+holdAddr, null, null);
	}
	
	public String revGeoLocation(double lat, double lon)
	{
		Geocoder geocoder = new Geocoder(getApplicationContext(), Locale.getDefault());
		String ret = "";
		try {
			List<Address> addresses = geocoder.getFromLocation(lat, lon, 1);
			if(addresses != null) {
				Address returnedAddress = addresses.get(0);
				StringBuilder strReturnedAddress = new StringBuilder("Address:\n");
				for(int i=0; i<returnedAddress.getMaxAddressLineIndex(); i++) {
					strReturnedAddress.append(returnedAddress.getAddressLine(i)).append("\n");
				}
				ret = strReturnedAddress.toString();
			}
			else{
				ret = "No Address returned!";
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			ret = "Can't get Address!";
		}
		return ret;
	}

}
