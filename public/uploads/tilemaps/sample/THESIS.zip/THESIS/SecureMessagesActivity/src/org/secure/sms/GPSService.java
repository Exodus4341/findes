package org.secure.sms;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.NetworkInfo.State;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.IBinder;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

public class GPSService extends Service{

	LocationManager mlocManager;
	LocationListener mlocListener;
	String text, website="\nVisit at {webtrackdroid.my.phpcloud.com/MapsGoogle} to locate the given lat/long values";
	String address, city1, country1, addressName="", addr_text="No reverse geocoding!", rev_geo="No reverse geocoding!";
	String myNumber;
	Boolean indicatorSent=false;
	//private final static int  LOCATION_UPDATE_TIME = 60000;//check every minutes
    //private final static int LOCATION_UPDATE_DISTANCE = 100;//don't bother if its not more than 100M
	
	
    @Override
	public IBinder onBind(Intent arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		// TODO Auto-generated method stub
		 super.onStartCommand(intent, flags, startId);
		 address= intent.getStringExtra("addr");
		 
	
		return 1;
		
	}
	
	
	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		TelephonyManager tm = (TelephonyManager)getSystemService(TELEPHONY_SERVICE);
   	 	myNumber = tm.getSimSerialNumber(); 
		
   	 new CountDownTimer(180000, 1000) { //3minutes

        public void onTick(long millisUntilFinished) {
           // mTextField.setText("seconds remaining: " + millisUntilFinished / 1000);
        	//Toast.makeText(getApplicationContext(), "seconds remaining: "+millisUntilFinished / 1000, Toast.LENGTH_SHORT).show();
        }

        public void onFinish() {
        	//Toast.makeText(getApplicationContext(), "DONE!", Toast.LENGTH_SHORT).show();
        	
        	if (indicatorSent==false){
        		//Toast.makeText(getApplicationContext(), "CANNOT GET LOCATION!", Toast.LENGTH_SHORT).show();
        		stopLocationListening();
        		stopSelf();
        		SmsManager smsManager = SmsManager.getDefault();
        		smsManager.sendTextMessage(address, null, "System-Reply:\nRequest is cancelled due to inability of GPS to calculate location by its signal strength. Try again later.", null, null);
        		
        	}
        }
     }.start();
   	 	
   	 	
   	 	try{
			String destPath = "/data/data/"+getPackageName()+"/databases/map-db";
			File f = new File(destPath);
			if (!f.exists()){
				CopyDB(getBaseContext().getAssets().open("mydb"),
						new FileOutputStream(destPath));
			}
		} catch (FileNotFoundException e){
			e.printStackTrace();
		} catch (IOException e){
			e.printStackTrace();
		}
		
		DBAdapter db = new DBAdapter(this);
		Toast.makeText( getApplicationContext(),myNumber, Toast.LENGTH_LONG ).show();
		Toast.makeText( getApplicationContext(),"ON START COMMAND ", Toast.LENGTH_SHORT ).show();
		mlocManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
		mlocListener = new MyLocationListener();
		
		ConnectivityManager network = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
		State wifi = network.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState();
		
		if (wifi == NetworkInfo.State.CONNECTED || wifi == NetworkInfo.State.CONNECTING) {
		   
			//Toast.makeText(getApplicationContext(), "WIFI", Toast.LENGTH_SHORT).show();
			//WifiManager wifiInfo = (WifiManager)getSystemService(Context.WIFI_SERVICE);
			//Toast.makeText(getApplicationContext(), wifiInfo.getConnectionInfo().toString(), Toast.LENGTH_LONG).show();
			
			db.open();
			Cursor c=db.getAllRecords();
			if (c.moveToFirst()){
				
				do{
					
					///////////////////////////////
					//HTTP POST DATA TO WEBSITE///
					///////////////////////////////

					HttpClient httpclient = new DefaultHttpClient();
					HttpPost httppost = new HttpPost("http://webtrackdroid.my.phpcloud.com/MapsGoogle/");

					try {

						//DateFormat dateFormat = new DateFormat();
						List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(5);
						nameValuePairs.add(new BasicNameValuePair("lat", c.getString(1) ));
						nameValuePairs.add(new BasicNameValuePair("lng", c.getString(2) ));
						nameValuePairs.add(new BasicNameValuePair("timecatch", c.getString(3)));
						nameValuePairs.add(new BasicNameValuePair("number", c.getString(4) ));
						nameValuePairs.add(new BasicNameValuePair("sim_serial_number",myNumber));
						UrlEncodedFormEntity p_entity = new UrlEncodedFormEntity(nameValuePairs,HTTP.UTF_8);
						httppost.setEntity(p_entity);
						//httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
						httpclient.execute(httppost);

					} catch (ClientProtocolException e) {
						Toast.makeText(this,
								"Client protocol exception ", Toast.LENGTH_LONG).show();
					} catch (IOException e) {
						Toast.makeText(this,
								"IO exception " + e.getMessage(), Toast.LENGTH_LONG)
								.show();
					}
					
					db.deleteRecord(c.getLong(0));
					///////////////////////////////
					//HTTP POST DATA TO WEBSITE///
					///////////////////////////////
					
				}while(c.moveToNext());
			}
			db.close();
			
			
		}
		
		if (!mlocManager.isProviderEnabled(LocationManager.GPS_PROVIDER))
		{
			mlocManager.requestLocationUpdates( LocationManager.NETWORK_PROVIDER, 0 ,0, mlocListener);
			Toast.makeText(getApplicationContext(), "LOCATION SYNC VIA NETWORK", Toast.LENGTH_SHORT).show();
			
			/*if (getLocationByProvider( LocationManager.NETWORK_PROVIDER)==null)
				Toast.makeText(getApplicationContext(), "NO NETWORK PROVIDER AVAILABLE "+mlocManager.isProviderEnabled( LocationManager.NETWORK_PROVIDER), Toast.LENGTH_SHORT).show();
			
			List<String> providers = mlocManager.getAllProviders();
			for (String p : providers) {
			   LocationProvider info = mlocManager.getProvider(p);
			   //Ln.d("printProvider "+info.toString()+" provider "+p);
			   Toast.makeText(getApplicationContext(), p+" "+info.toString(), Toast.LENGTH_LONG).show();
			   
			}*/
			
			if (wifi == NetworkInfo.State.CONNECTED || wifi == NetworkInfo.State.CONNECTING) {
			    //wifi
				Toast.makeText(getApplicationContext(), "WIFI", Toast.LENGTH_SHORT).show();
				WifiManager wifiInfo = (WifiManager)getSystemService(Context.WIFI_SERVICE);
				Toast.makeText(getApplicationContext(), wifiInfo.getConnectionInfo().toString(), Toast.LENGTH_LONG).show();
			/*	
				db.open();
				Cursor c=db.getAllRecords();
				if (c.moveToFirst()){
					
					do{
						sendToWebsite(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),address);
					}while(c.moveToNext());
				}
				db.close();
				*/
				
			}
			
			
		}
		else{
			mlocManager.requestLocationUpdates( LocationManager.GPS_PROVIDER, 0, 0, mlocListener);
			Toast.makeText(getApplicationContext(), "LOCATION SYNC VIA GPS", Toast.LENGTH_SHORT).show();
		}
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}

	private void getLocation (Location loc)
	{
		stopLocationListening();
		String s= "";
    	Date date = new Date();
    	Format formatter;
    	//formatter = new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss Z");
    	formatter = new SimpleDateFormat("MMMM dd yyyy HH:mm:ss ");
    	s = formatter.format(date);
    	String lat =  Double.toString(loc.getLatitude());
		String lng =  Double.toString(loc.getLongitude());
		text = "My current location is: " +"\nLatitude = " + lat +"\nLongitude = " + lng;
		
        
		/////////////////////////////
		////STORE DATA IN SQLITE/////
		/////////////////////////////
		
		ConnectivityManager network = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
		State wifi = network.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState();
		if (wifi != NetworkInfo.State.CONNECTED ){
			DBAdapter db = new DBAdapter(this);
			db.open();
			 db.insertRecord(Double.toString(loc.getLatitude()), Double.toString(loc.getLongitude()), s, address);
			 Toast.makeText(this,"SMSReceiver: Data is sent to a local storage. ", Toast.LENGTH_LONG).show();
			db.close();
		}
		
		/////////////////////////////
		////STORE DATA IN SQLITE/////
		/////////////////////////////
		
		
		/////////////////
		//SMS SEND BACK//
		/////////////////
		//+"http://webtrackdroid.my.phpcloud.com/MapsGoogle/?lat="+loc.getLatitude()+"&lng="+loc.getLongitude()
		//+"http://webtrackdroid.my.phpcloud.com/MapsGoogle/?lat="+lat+"&lng="+lng

		SmsManager smsManager = SmsManager.getDefault();
		smsManager.sendTextMessage(address, null, text+" \nSIM serial number:  "+myNumber, null, null);
		indicatorSent=true;
		/////////////////
		//SMS SEND BACK//
		/////////////////
		
		///////////////////////////////
		//HTTP POST DATA TO WEBSITE///
		///////////////////////////////
		
		
		HttpClient httpclient = new DefaultHttpClient();
		HttpPost httppost = new HttpPost("http://webtrackdroid.my.phpcloud.com/MapsGoogle/");
		
		 
	   
	        try {
	        	
	        	//DateFormat dateFormat = new DateFormat();	
	        	List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(5);
				nameValuePairs.add(new BasicNameValuePair("lat", lat ));
				nameValuePairs.add(new BasicNameValuePair("lng", lng ));
				nameValuePairs.add(new BasicNameValuePair("timecatch",s));
				nameValuePairs.add(new BasicNameValuePair("number", address ));
				nameValuePairs.add(new BasicNameValuePair("sim_serial_number",myNumber));
				UrlEncodedFormEntity p_entity = new UrlEncodedFormEntity(nameValuePairs,HTTP.UTF_8);
				 httppost.setEntity(p_entity);
				//httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
	             httpclient.execute(httppost);
	        
	            Toast.makeText(this,"SMSReceiver: Data is sent to a dedicated website. ", Toast.LENGTH_LONG).show();
	            
	        } catch (ClientProtocolException e) {
	            Toast.makeText(this,
	                    "Client protocol exception ", Toast.LENGTH_LONG).show();
	        } catch (IOException e) {
	            Toast.makeText(this,
	                    "IO exception " + e.getMessage(), Toast.LENGTH_LONG)
	                    .show();
	        }
	        ///////////////////////////////
	        //HTTP POST DATA TO WEBSITE///
	        ///////////////////////////////
	       
		
		
		stopSelf();
		
	}

	
	private void stopLocationListening()
	{
		mlocManager.removeUpdates(mlocListener);
	}
	
	
	public class MyLocationListener implements LocationListener
	
	{
		
			@Override
			
			public void onLocationChanged(Location loc)
			{
				getLocation(loc);
			}
			
			
			@Override
			
			public void onProviderDisabled(String provider)
			
			{
			
			Toast.makeText( getApplicationContext(),"GPS is Disabled!",Toast.LENGTH_SHORT ).show();
			text = "GPS IS DISABLED!";
			//Intent myIntent = getIntent();
			//String pAddress = myIntent.getStringExtra("addr");
			SmsManager smsManager = SmsManager.getDefault();
			smsManager.sendTextMessage(address, null, text, null, null);
			
			}
			
			
			@Override
			
				public void onProviderEnabled(String provider)
				
				{
				
				Toast.makeText( getApplicationContext(),"GPS is Enabled",Toast.LENGTH_SHORT).show();
				text = "GPS IS ENABLED!";
				
				
				}
			
			
			@Override
			
				public void onStatusChanged(String provider, int status, Bundle extras)
				
				{
				
				
				}
	
		} //End of Class MyLocationListener 
	
	public void CopyDB(InputStream inputStream, OutputStream outputStream) throws IOException{
		byte[] buffer = new byte[1024];
		int length;
		while((length=inputStream.read(buffer))>0){
			outputStream.write(buffer,0,length);
		}
		inputStream.close();
		outputStream.close();
	}
	
	private void sendToWebsite(long id, String lat, String lng, String timecatch, String addr){
	///////////////////////////////
	//HTTP POST DATA TO WEBSITE///
	///////////////////////////////

	HttpClient httpclient = new DefaultHttpClient();
	HttpPost httppost = new HttpPost("http://webtrackdroid.my.phpcloud.com/MapsGoogle/");

	try {

		//DateFormat dateFormat = new DateFormat();
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(4);
		nameValuePairs.add(new BasicNameValuePair("lat", lat ));
		nameValuePairs.add(new BasicNameValuePair("lng", lng ));
		nameValuePairs.add(new BasicNameValuePair("timecatch", timecatch));
		nameValuePairs.add(new BasicNameValuePair("number", addr ));
		UrlEncodedFormEntity p_entity = new UrlEncodedFormEntity(nameValuePairs,HTTP.UTF_8);
		httppost.setEntity(p_entity);
		//httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
		httpclient.execute(httppost);
		Log.d("TAG", "Data sent!");
		Toast.makeText(this,
				"Data Sent ", Toast.LENGTH_LONG).show();

	} catch (ClientProtocolException e) {
		Toast.makeText(this,
				"Client protocol exception ", Toast.LENGTH_LONG).show();
	} catch (IOException e) {
		Toast.makeText(this,
				"IO exception " + e.getMessage(), Toast.LENGTH_LONG)
				.show();
	}
	DBAdapter db = new DBAdapter(this);
	db.deleteRecord(id);
	///////////////////////////////
	//HTTP POST DATA TO WEBSITE///
	///////////////////////////////
	}

}
