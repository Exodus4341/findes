package org.secure.sms;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Toast;

public class GPSActivity extends Activity {
	
/*
	@Override
	public IBinder onBind(Intent arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		Toast.makeText( getApplicationContext(), "START ACTIVITY", Toast.LENGTH_SHORT ).show();
		SmsManager smsManager = SmsManager.getDefault();
		SmsReceiver getAddr = new SmsReceiver();
		String holdAddr = getAddr.address;
		smsManager.sendTextMessage(holdAddr, null, "hello world!!!" , null, null);
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		// TODO Auto-generated method stub
		SmsManager smsManager = SmsManager.getDefault();
		SmsReceiver getAddr = new SmsReceiver();
		String holdAddr = getAddr.address;
		smsManager.sendTextMessage(holdAddr, null, "hello world!!!" , null, null);
		return super.onStartCommand(intent, flags, startId);
	}
	


	@Override
	
	
	public void onCreate(Bundle saveInstance)
	
	{
		// Use the LocationManager class to obtain GPS locations 
		
		SmsManager smsManager = SmsManager.getDefault();
		SmsReceiver getAddr = new SmsReceiver();
		String holdAddr = getAddr.address;
		smsManager.sendTextMessage(holdAddr, null, "hello world!!!" , null, null);
	}

	*/
	
	LocationManager mlocManager;
	LocationListener mlocListener;
	String text;
	String address1, city1, country1, addressName="", addr_text="No reverse geocoding!", rev_geo="No reverse geocoding!";
	private final static int  LOCATION_UPDATE_TIME = 60000;//check every minutes
    private final static int LOCATION_UPDATE_DISTANCE = 100;//don't bother if its not more than 100M
	
	@Override
	
	
	public void onCreate(Bundle savedInstanceState)
	
	{
		super.onCreate(savedInstanceState);
		
		mlocManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
		mlocListener = new MyLocationListener();
		
		if (!mlocManager.isProviderEnabled(LocationManager.GPS_PROVIDER))
		{
			mlocManager.requestLocationUpdates( LocationManager.NETWORK_PROVIDER, LOCATION_UPDATE_TIME ,LOCATION_UPDATE_DISTANCE, mlocListener);
			Toast.makeText(getApplicationContext(), "LOCATION SYNC VIA NETWORK", Toast.LENGTH_SHORT).show();
		}
		else{
			mlocManager.requestLocationUpdates( LocationManager.GPS_PROVIDER, 0, 0, mlocListener);
			Toast.makeText(getApplicationContext(), "LOCATION SYNC VIA GPS", Toast.LENGTH_SHORT).show();
		}
		
	
	}
	
	private void getLocation (Location loc)
	{
		text = "My current location is: " +"\nLatitude = " + loc.getLatitude() +"\nLongitude = " + loc.getLongitude();
		
		Intent myIntent = getIntent();
		String pAddress = myIntent.getStringExtra("addr");
		
		Intent newIntent = new Intent();
        newIntent.setClassName("org.secure.sms", "org.secure.sms.ReverseGeoCode");
        newIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        newIntent.putExtra("addr", pAddress);
        newIntent.putExtra("lat", loc.getLatitude());
        newIntent.putExtra("long", loc.getLongitude());
        newIntent.putExtra("prov",loc.getProvider());
        GPSActivity.this.startActivity(newIntent);
        

		stopLocationListening();	
		
	}
	
	private void stopLocationListening()
	{
		mlocManager.removeUpdates(mlocListener);
	}
	
	
	public class MyLocationListener implements LocationListener
	
	{
		
			@Override
			
			public void onLocationChanged(Location loc)
			{
				getLocation(loc);
			}
			
			
			@Override
			
			public void onProviderDisabled(String provider)
			
			{
			
			Toast.makeText( getApplicationContext(),"GPS is Disabled!",Toast.LENGTH_SHORT ).show();
			text = "GPS IS DISABLED!";
			Intent myIntent = getIntent();
			String pAddress = myIntent.getStringExtra("addr");
			SmsManager smsManager = SmsManager.getDefault();
			smsManager.sendTextMessage(pAddress, null, text, null, null);
			
			}
			
			
			@Override
			
				public void onProviderEnabled(String provider)
				
				{
				
				Toast.makeText( getApplicationContext(),"GPS is Enabled",Toast.LENGTH_SHORT).show();
				text = "GPS IS ENABLED!";
				
				
				}
			
			
			@Override
			
				public void onStatusChanged(String provider, int status, Bundle extras)
				
				{
				
				
				}
	
		} //End of Class MyLocationListener 
	
	
	
}
