package org.secure.sms;

import java.util.regex.Pattern;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.telephony.SmsMessage;
import android.widget.Toast;

public class SmsReceiver extends BroadcastReceiver
{
	
	public static final String SMS_EXTRA_NAME = "pdus";
	public static final String SMS_URI = "content://sms";
	
	public static final String ADDRESS = "address";
    public static final String PERSON = "person";
    public static final String DATE = "date";
    public static final String READ = "read";
    public static final String STATUS = "status";
    public static final String TYPE = "type";
    public static final String BODY = "body";
    public static final String SEEN = "seen";
    
    public static final int MESSAGE_TYPE_INBOX = 1;
    public static final int MESSAGE_TYPE_SENT = 2;
    
    public static final int MESSAGE_IS_NOT_READ = 0;
    public static final int MESSAGE_IS_READ = 1;
    
    public static final int MESSAGE_IS_NOT_SEEN = 0;
    public static final int MESSAGE_IS_SEEN = 1;
    
    public String cPhoneNumber="";
    public String address, myNumber;
    private Context context1;
	
    // Change the password here or give a user possibility to change it
    //public static final byte[] PASSWORD = new byte[]{ 0x20, 0x32, 0x34, 0x47, (byte) 0x84, 0x33, 0x58 };
    
	public void onReceive( Context context, Intent intent ) 
	{
		
		
		
		// Get SMS map from Intent
        Bundle extras = intent.getExtras();
        
        String messages = "";
        
        if ( extras != null )
        {
            // Get received SMS array
            Object[] smsExtra = (Object[]) extras.get( SMS_EXTRA_NAME );
            
            // Get ContentResolver object for pushing encrypted SMS to incoming folder
            ContentResolver contentResolver = context.getContentResolver();
            
            for ( int i = 0; i < smsExtra.length; ++i )
            {
            	SmsMessage sms = SmsMessage.createFromPdu((byte[])smsExtra[i]);
            	
            	String body = sms.getMessageBody().toString();
            	 address = sms.getOriginatingAddress();
            	 
               
                messages += "SMS from " + address + " :\n";                    
                messages += body + "\n";
                
                
                boolean op1;
    			String keyword = "musta nak";
    			// identify matches of a keyword based request from incoming SMS
    			op1 = Pattern.compile(keyword).matcher(body.toLowerCase()).matches();
                //op2 = Pattern.compile("Request trackloc").matcher(body).matches();
                
    			if ( !op1 ) {
    				putSmsToDatabase( contentResolver, sms );
    				//disableGPS(context);
    				// Toast.makeText( context,"NOT EQUAL!", Toast.LENGTH_SHORT ).show();
    			}
    			else {
    				
    				Toast.makeText( context,"WORKING OPERATION 1", Toast.LENGTH_SHORT ).show();
    				Intent myIntent = new Intent();
    		        myIntent.setClassName("org.secure.sms", "org.secure.sms.GPSService");
    		        myIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    		        myIntent.putExtra("addr", address);
    		        context.startService(myIntent);
    		        
    		       
    		        
    		        if (isMyServiceRunning(context)==true){
    		        	
    		        }
    		        context.stopService(myIntent);
    		    }
    		
            }
            
            // Display SMS message
            Toast.makeText( context, messages, Toast.LENGTH_SHORT ).show();
        }
        
        this.abortBroadcast(); 
	}
	




	private void putSmsToDatabase( ContentResolver contentResolver, SmsMessage sms )
	{
		// Create SMS row
        ContentValues values = new ContentValues();
        values.put( ADDRESS, sms.getOriginatingAddress() );
        values.put( DATE, sms.getTimestampMillis() );
        values.put( READ, MESSAGE_IS_NOT_READ );
        values.put( STATUS, sms.getStatus() );
        values.put( TYPE, MESSAGE_TYPE_INBOX );
        values.put( SEEN, MESSAGE_IS_NOT_SEEN );
        values.put( BODY, sms.getMessageBody().toString()  );
        /*try
        {
        	String encryptedPassword = StringCryptor.encrypt( new String(PASSWORD), sms.getMessageBody().toString() ); 
        	values.put( BODY, encryptedPassword );
        }
        catch ( Exception e ) 
        { 
        	e.printStackTrace(); 
    	}*/
        
        
        // Push row into the SMS table
        contentResolver.insert( Uri.parse( SMS_URI ), values );
	}
	/*
	private static ContentResolver getContentResolver() {
		// TODO Auto-generated method stub
		return null;
	}
	
	private static void enableGPS( Context context ) {
		Intent gps=new Intent("android.location.GPS_ENABLED_CHANGE");
		gps.putExtra("enabled", true);
		context.sendBroadcast(gps);

	}
	
	private static void disableGPS ( Context context ){
		Intent gps = new Intent("android.location.GPS_ENABLED_CHANGE");
		gps.putExtra("enabled", false);
		context.sendBroadcast(gps);
	}*/
	private boolean isMyServiceRunning(Context context) {
	    ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
	    for (RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
	        if (GPSService.class.getName().equals(service.service.getClassName())) {
	            return true;
	        }
	    }
	    return false;
	}
	
	
}
