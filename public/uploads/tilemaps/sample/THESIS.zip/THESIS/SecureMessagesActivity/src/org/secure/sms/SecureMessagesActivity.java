package org.secure.sms;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

public class SecureMessagesActivity extends Activity implements OnClickListener
{
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        
        setTheme( android.R.style.Theme_Light );
        setContentView(R.layout.main);
        
        /**
         * You can also register your intent filter here.
         * And here is example how to do this.
         *
         * IntentFilter filter = new IntentFilter( "android.provider.Telephony.SMS_RECEIVED" );
         * filter.setPriority( IntentFilter.SYSTEM_HIGH_PRIORITY );
         * registerReceiver( new SmsReceiver(), filter );
        **/
        
        this.findViewById( R.id.UpdateList ).setOnClickListener( this );
    }

    ArrayList<String> smsList = new ArrayList<String>();
    /*
	public void onItemClick( AdapterView<?> parent, View view, int pos, long id ) 
	{
		try 
		{
		    	String[] splitted = smsList.get( pos ).split("\n"); 
			String sender = splitted[0];
			String encryptedData = "";
			for ( int i = 1; i < splitted.length; ++i )
			{
			    encryptedData += splitted[i];
			}
			String data = sender + "\n" + StringCryptor.decrypt( new String(SmsReceiver.PASSWORD), encryptedData );
			Toast.makeText( this, data, Toast.LENGTH_SHORT ).show();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}*/

	public void onClick( View v ) 
	{
		SmsReceiver sms = new SmsReceiver();
		
		String pNum = new SmsReceiver().cPhoneNumber;
		TextView out = (TextView) findViewById(R.id.output);
		if (pNum!=null){
			out.setText(pNum);
		}
		else out.setText(pNum);
		/*ContentResolver contentResolver = getContentResolver();
		Cursor cursor = contentResolver.query( Uri.parse( "content://sms/inbox" ), null, null, null, null);

		int indexBody = cursor.getColumnIndex( SmsReceiver.BODY );
		int indexAddr = cursor.getColumnIndex( SmsReceiver.ADDRESS );
		int indexDateReceived = cursor.getColumnIndex( SmsReceiver.DATE);
		if ( indexBody < 0 || !cursor.moveToFirst() ) return;
		
		smsList.clear();
		
		do
		{
			String str = "Sender: " + cursor.getString( indexAddr ) + "\nMessage: \n" + cursor.getString( indexBody )
					+ "\n\nDate Received: ";
			str = str + millisToDate(cursor.getLong(indexDateReceived));
			smsList.add( str );
			
		}
		while( cursor.moveToNext() );

		
		ListView smsListView = (ListView) findViewById( R.id.SMSList );
		smsListView.setAdapter( new ArrayAdapter<String>( this, android.R.layout.simple_list_item_1, smsList) );
		*/
		//smsListView.setOnItemClickListener( this );
	}
	
	public static String millisToDate(long currentTime) {
	    String finalDate;
	    Calendar calendar = Calendar.getInstance();
	    calendar.setTimeInMillis(currentTime);
	    Date date = calendar.getTime();
	    finalDate = date.toString();
	    return finalDate;
	}
}